<?php

namespace Addons\Robot\Controller;
use Home\Controller\AddonsController;

class RobotController extends AddonsController{

}
