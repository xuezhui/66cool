<?php

namespace Addons\CustomReply\Model;
use Think\Model;

/**
 * CustomReply模型
 */
class CustomReplyModel extends Model{

}
