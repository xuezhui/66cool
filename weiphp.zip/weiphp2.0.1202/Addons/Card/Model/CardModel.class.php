<?php

namespace Addons\Card\Model;
use Think\Model;

/**
 * Card模型
 */
class CardModel extends Model{

}
