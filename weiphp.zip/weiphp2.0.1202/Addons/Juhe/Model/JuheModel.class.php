<?php

namespace Addons\Juhe\Model;
use Think\Model;

/**
 * Juhe模型
 */
class JuheModel extends Model{

}
