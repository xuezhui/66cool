<?php

namespace Addons\Coupon\Model;
use Think\Model;

/**
 * Coupon模型
 */
class CouponModel extends Model{

}
