<?php

namespace Addons\Suggestions\Model;
use Think\Model;

/**
 * Suggestions模型
 */
class SuggestionsModel extends Model{

}
