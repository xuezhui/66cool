<?php
return array (
		'need_nickname' => array (
				'title' => '是否需要填写昵称:',
				'type' => 'radio',
				'options' => array (
						'1' => '是',
						'0' => '否' 
				),
				'value' => '0' 
		),
		'need_mobile' => array (
				'title' => '是否需要填写手机号:',
				'type' => 'radio',
				'options' => array (
						'1' => '是',
						'0' => '否' 
				),
				'value' => '0' 
		) 
);
					