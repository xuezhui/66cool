<?php

namespace Addons\Tongji\Model;
use Think\Model;

/**
 * Tongji模型
 */
class TongjiModel extends Model{

}
