<?php

namespace Addons\Leaflets\Model;
use Think\Model;

/**
 * Leaflets模型
 */
class LeafletsModel extends Model{

}
