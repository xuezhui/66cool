<?php

namespace Addons\Third\Controller;

use Home\Controller\AddonsController;


class BaseController extends AddonsController {
	

	//这里可以添加站内的一些常用插件或在这做一些接口中转，如快递查询等
	
}

