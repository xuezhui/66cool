<?php

namespace Addons\Third\Model;
use Think\Model;

/**
 * Third模型
 */
class ThirdModel extends Model{

}
