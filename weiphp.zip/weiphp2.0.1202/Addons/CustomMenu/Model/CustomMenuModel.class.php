<?php

namespace Addons\CustomMenu\Model;
use Think\Model;

/**
 * CustomMenu模型
 */
class CustomMenuModel extends Model{

}
