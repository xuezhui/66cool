<?php

define("PARTNER", "2088302419653203");
define("KEY", "i7uwgfuq8q9i5wnlfoiuygpfx5c6xr94");
define("SELLER_EMAIL", "13994151145");
define("NOTIFY_URL", "http://www.wtsqc.com/qc/Modules/Index/Tpl/Public/Play/notify_url.php");
define("RETURN_URL", "http://www.wtsqc.com/qc/Modules/Index/Tpl/Public/Play/return_url.php");
$notify_url=NOTIFY_URL;
$return_url=RETURN_URL;
$partner=PARTNER;
$key=KEY;
$seller_email=SELLER_EMAIL;
/* echo $seller_email;
echo "<br/>";
echo $key;
echo "<br/>";
echo $notify_url;
echo "<br/>";
echo $return_url;
echo "<br/>";
echo $partner; */
?>