<?php

namespace Addons\Diy\Model;
use Think\Model;

/**
 * Diy模型
 */
class DiyModel extends Model{

}
